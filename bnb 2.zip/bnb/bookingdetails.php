<?php
include "checksession.php";
checkUser();
loginStatus();
 
include "config.php";
 
$DBC = new mysqli(DBHOST, DBUSER, DBPASSWORD, DBDATABASE, DBPORT);
if ($DBC->connect_errno) {
    die("Error: Unable to connect to MySQL. " . $DBC->connect_error);
}
 
$id = filter_input(INPUT_GET, 'id', FILTER_VALIDATE_INT);
if (!$id) {
    die("<h2>Invalid or missing booking ID</h2>");
}
 

$query = "
    SELECT booking.bookingID, room.roomname, room.description,
           room.roomtype, room.beds, booking.check_in_date, 
           booking.check_out_date, booking.contactnumber,
           booking.booking_extras, booking.room_review
    FROM booking
    INNER JOIN room ON booking.roomID = room.roomID
    WHERE booking.bookingID = ?
";
 
$stmt = $DBC->prepare($query);
$stmt->bind_param("i", $id);
$stmt->execute();
$result = $stmt->get_result();
$rowcount = $result->num_rows;
 
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Booking Information</title>
    <style>
        body {
            background-color: #eef2f3;
            font-family: 'Segoe UI', sans-serif;
            margin: 40px;
        }
        .container {
            max-width: 700px;
            margin: auto;
            background: #fff;
            padding: 25px;
            border-radius: 10px;
            box-shadow: 0 0 10px rgba(0,0,0,0.1);
        }
        h1 {
            color: #444;
            margin-bottom: 20px;
        }
        .nav {
            margin-bottom: 20px;
        }
        .nav a {
            margin-right: 20px;
            color: #0066cc;
            text-decoration: none;
        }
        .nav a:hover {
            text-decoration: underline;
        }
        table {
            width: 100%;
            border-collapse: collapse;
            margin-top: 10px;
        }
        th, td {
            text-align: left;
            padding: 10px;
            vertical-align: top;
        }
        th {
            width: 30%;
            background-color: #f5f5f5;
            color: #333;
        }
        td {
            background-color: #fafafa;
        }
    </style>
</head>
<body>

<div class="container">
    <h1>Booking Information</h1>
    <div class="nav">
        <a href="bookinglisting.php">Back to Bookings</a>
        <a href="index.php">Home</a>
    </div>

    <?php
    if ($rowcount > 0) {
        $row = mysqli_fetch_array($result, MYSQLI_ASSOC);
        echo "<table>";
        echo "<tr><th>Room Name</th><td>" . htmlspecialchars($row['roomname']) . "</td></tr>";
        echo "<tr><th>Description</th><td>" . htmlspecialchars($row['description']) . "</td></tr>";
        echo "<tr><th>Room Type</th><td>" . htmlspecialchars($row['roomtype']) . "</td></tr>";
        echo "<tr><th>Beds</th><td>" . htmlspecialchars($row['beds']) . "</td></tr>";
        echo "<tr><th>Check-in Date</th><td>" . htmlspecialchars($row['check_in_date']) . "</td></tr>";
        echo "<tr><th>Check-out Date</th><td>" . htmlspecialchars($row['check_out_date']) . "</td></tr>";
        echo "<tr><th>Contact Number</th><td>" . htmlspecialchars($row['contactnumber']) . "</td></tr>";
        echo "<tr><th>Booking Extras</th><td>" . htmlspecialchars($row['booking_extras']) . "</td></tr>";
        echo "<tr><th>Room Review</th><td>" . htmlspecialchars($row['room_review']) . "</td></tr>";
        echo "</table>";
    } else {
        echo "<p>No booking record found. It might have been removed.</p>";
    }

    if (isset($stmt)) $stmt->close();
    if (isset($DBC)) $DBC->close();
    ?>
</div>

</body>
</html>
