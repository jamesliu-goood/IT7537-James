<?php
include "checksession.php";
checkUser();
loginStatus();
 
include "config.php";
 
$DBC = new mysqli(DBHOST, DBUSER, DBPASSWORD, DBDATABASE, DBPORT);
 
if ($DBC->connect_errno) {
    die("Error: Unable to connect to MySQL. " . $DBC->connect_error);
}
 
$query = "
    SELECT booking.bookingID, room.roomname, booking.check_in_date, booking.check_out_date,
           customer.firstname, customer.lastname
    FROM booking
    INNER JOIN room ON booking.roomID = room.roomID
    INNER JOIN customer ON booking.customerID = customer.customerID
    ORDER BY bookingID
";
 
$result = $DBC->query($query);
$rowcount = $result->num_rows;
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<title>All Bookings</title>
<style>
    body {
        font-family: 'Segoe UI', sans-serif;
        background-color: #eef1f5;
        padding: 30px;
        color: #333;
    }
    .header {
        margin-bottom: 30px;
    }
    .header h1 {
        margin-bottom: 10px;
    }
    .nav-links a {
        margin-right: 20px;
        color: #0066cc;
        text-decoration: none;
        font-weight: bold;
    }
    .nav-links a:hover {
        text-decoration: underline;
    }
    .booking-card {
        background: #fff;
        border-left: 5px solid #007BFF;
        margin-bottom: 20px;
        padding: 20px;
        box-shadow: 0 2px 8px rgba(0,0,0,0.05);
        border-radius: 5px;
    }
    .booking-card h3 {
        margin-top: 0;
    }
    .booking-details {
        margin: 10px 0;
    }
    .actions a {
        margin-right: 15px;
        color: #007BFF;
        font-size: 0.95em;
    }
    .actions a:hover {
        text-decoration: underline;
    }
</style>
</head>
<body>

<div class="header">
    <h1>All Current Bookings</h1>
    <div class="nav-links">
        <a href="bookingroom.php">New Booking</a>
        <a href="index.php">Home</a>
    </div>
</div>

<?php if ($rowcount > 0): ?>
    <?php while ($booking = mysqli_fetch_array($result, MYSQLI_ASSOC)): ?>
        <div class="booking-card">
            <h3><?= htmlspecialchars($booking['roomname']) ?></h3>
            <div class="booking-details">
                <strong>Customer:</strong> <?= htmlspecialchars($booking['firstname'] . ' ' . $booking['lastname']) ?><br>
                <strong>Dates:</strong> <?= htmlspecialchars($booking['check_in_date']) ?> → <?= htmlspecialchars($booking['check_out_date']) ?>
            </div>
            <div class="actions">
                <a href="bookingdetails.php?id=<?= $booking['bookingID'] ?>">Details</a>
                <a href="editbooking.php?id=<?= $booking['bookingID'] ?>">Edit</a>
                <a href="editseats.php?id=<?= $booking['bookingID'] ?>">Review</a>
                <a href="deletebooking.php?id=<?= $booking['bookingID'] ?>" onclick="return confirm('Delete this booking?');">Delete</a>
            </div>
        </div>
    <?php endwhile; ?>
<?php else: ?>
    <p>No bookings available at the moment.</p>
<?php endif; ?>

<?php
$result->free();
$DBC->close();
?>

</body>
</html>
