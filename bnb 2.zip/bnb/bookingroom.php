<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<title>Create New Booking</title>
<meta name="viewport" content="width=device-width, initial-scale=1">
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
<link rel="stylesheet" href="//code.jquery.com/ui/1.13.1/themes/base/jquery-ui.css">
<script src="https://code.jquery.com/jquery-3.6.0.js"></script>
<script src="https://code.jquery.com/ui/1.13.1/jquery-ui.js"></script>
<script>
$(function () {
    $("#checkin, #checkout, #searchFrom, #searchTo").datepicker({ dateFormat: "yy-mm-dd" });

    $("#bookingSearch").on("submit", function (e) {
        e.preventDefault();
        const from = $("#searchFrom").val();
        const to = $("#searchTo").val();

        if (from > to) {
            alert("From date cannot be later than To date.");
            return;
        }

        fetch(`bookingsearch.php?fromDate=${from}&toDate=${to}`)
            .then(response => response.text())
            .then(html => {
                document.querySelector("#searchResults").innerHTML = html;
            })
            .catch(err => {
                document.querySelector("#searchResults").innerHTML = "<tr><td colspan='5'>Error loading results</td></tr>";
                console.error(err);
            });
    });
});
</script>
</head>
<body class="container mt-4">

<?php
include "checksession.php";
checkUser();
loginStatus();
include "config.php";

$DBC = new mysqli(DBHOST, DBUSER, DBPASSWORD, DBDATABASE, DBPORT);
if ($DBC->connect_error) {
    die("<div class='alert alert-danger'>Connection failed: " . $DBC->connect_error . "</div>");
}

function clean($data) {
    return htmlspecialchars(trim($data));
}

if ($_SERVER["REQUEST_METHOD"] === "POST" && $_POST["submit"] === "Book Now") {
    $room = clean($_POST['room']);
    $customer = clean($_POST['customer']);
    $checkin = clean($_POST['checkin']);
    $checkout = clean($_POST['checkout']);
    $contact = clean($_POST['contact']);
    $extras = clean($_POST['extras']);
    $review = clean($_POST['review']);

    if (strtotime($checkin) >= strtotime($checkout)) {
        echo "<div class='alert alert-warning'>Check-out date must be after check-in.</div>";
    } else {
        $stmt = $DBC->prepare("INSERT INTO booking (roomID, customerID, check_in_date, check_out_date, contactnumber, booking_extras, room_review) VALUES (?, ?, ?, ?, ?, ?, ?)");
        $stmt->bind_param("iisssss", $room, $customer, $checkin, $checkout, $contact, $extras, $review);

        if ($stmt->execute()) {
            echo "<div class='alert alert-success'>Booking successfully created.</div>";
        } else {
            echo "<div class='alert alert-danger'>Error: {$stmt->error}</div>";
        }
        $stmt->close();
    }
}

$rooms = $DBC->query("SELECT roomID, roomname FROM room");
$customers = $DBC->query("SELECT customerID, firstname, lastname FROM customer");
?>

<h2>Room Booking Form</h2>
<form method="POST" class="row g-3">
    <div class="col-md-6">
        <label for="room" class="form-label">Room</label>
        <select name="room" id="room" class="form-select" required>
            <?php while ($r = $rooms->fetch_assoc()): ?>
                <option value="<?= $r['roomID'] ?>"><?= htmlspecialchars($r['roomname']) ?></option>
            <?php endwhile; ?>
        </select>
    </div>
    <div class="col-md-6">
        <label for="customer" class="form-label">Customer</label>
        <select name="customer" id="customer" class="form-select" required>
            <?php while ($c = $customers->fetch_assoc()): ?>
                <option value="<?= $c['customerID'] ?>"><?= htmlspecialchars($c['firstname'] . ' ' . $c['lastname']) ?></option>
            <?php endwhile; ?>
        </select>
    </div>
    <div class="col-md-6">
        <label class="form-label">Check-in</label>
        <input type="text" id="checkin" name="checkin" class="form-control" required>
    </div>
    <div class="col-md-6">
        <label class="form-label">Check-out</label>
        <input type="text" id="checkout" name="checkout" class="form-control" required>
    </div>
    <div class="col-6">
        <label class="form-label">Contact Number</label>
        <input type="text" name="contact" class="form-control" required>
    </div>
    <div class="col-6">
        <label class="form-label">Booking Extras</label>
        <input type="text" name="extras" class="form-control">
    </div>
    <div class="col-12">
        <label class="form-label">Room Review</label>
        <input type="text" name="review" class="form-control">
    </div>
    <div class="col-12">
        <button type="submit" name="submit" value="Book Now" class="btn btn-primary">Book Now</button>
    </div>
</form>

<hr class="my-4">

<h3>Search Existing Bookings</h3>
<form id="bookingSearch" class="row g-2">
    <div class="col-md-5">
        <input type="text" id="searchFrom" name="fromDate" class="form-control" placeholder="From date" required>
    </div>
    <div class="col-md-5">
        <input type="text" id="searchTo" name="toDate" class="form-control" placeholder="To date" required>
    </div>
    <div class="col-md-2">
        <button type="submit" class="btn btn-secondary w-100">Search</button>
    </div>
</form>

<table class="table table-bordered mt-4">
    <thead class="table-light">
        <tr>
            <th>ID</th><th>Room</th><th>Check-in</th><th>Check-out</th><th>Customer</th>
        </tr>
    </thead>
    <tbody id="searchResults">
        <tr><td colspan="5">No results yet.</td></tr>
    </tbody>
</table>

<?php $DBC->close(); ?>
</body>
</html>
