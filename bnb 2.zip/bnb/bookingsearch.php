<?php

require_once "config.php";

$start = $_GET['fromDate'] ?? '';
$end = $_GET['toDate'] ?? '';

if (!$start || !$end || strtotime($start) > strtotime($end)) {
    echo "<tr><td colspan='5'>Please select a valid date range.</td></tr>";
    exit;
}

$conn = new mysqli(DBHOST, DBUSER, DBPASSWORD, DBDATABASE, DBPORT);

if ($conn->connect_error) {
    echo "<tr><td colspan='5'>Connection error: " . htmlspecialchars($conn->connect_error) . "</td></tr>";
    exit;
}
$sql = <<<SQL
    SELECT r.roomID, r.roomname, r.description, r.roomtype, r.beds
    FROM room r
    WHERE r.roomID NOT IN (
        SELECT b.roomID
        FROM booking b
        WHERE b.check_in_date < ? AND b.check_out_date > ?
    )
    ORDER BY r.roomID
SQL;

$statement = $conn->prepare($sql);

if (!$statement) {
    echo "<tr><td colspan='5'>Query preparation failed.</td></tr>";
    exit;
}

$statement->bind_param("ss", $end, $start);
$statement->execute();
$results = $statement->get_result();

if ($results->num_rows > 0) {
    foreach ($results as $room) {
        echo "<tr>";
        echo "<td>" . htmlspecialchars($room['roomID']) . "</td>";
        echo "<td>" . htmlspecialchars($room['roomname']) . "</td>";
        echo "<td>" . htmlspecialchars($room['description']) . "</td>";
        echo "<td>" . htmlspecialchars($room['roomtype']) . "</td>";
        echo "<td>" . htmlspecialchars($room['beds']) . "</td>";
        echo "</tr>";
    }
} else {
    echo "<tr><td colspan='5'>No rooms available during this period.</td></tr>";
}

$statement->close();
$conn->close();
?>
