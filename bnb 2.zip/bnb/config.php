<?php
//MySQL credentails
define("DBUSER","root");
define("DBPASSWORD","root");
define("DBDATABASE","bnb");
define("DBHOST", "127.0.0.1");
define("DBPORT", 3308)
?>