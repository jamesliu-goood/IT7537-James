<?php

include "checksession.php";
checkUser();
loginStatus();

include "config.php";

$bookingID = filter_input(INPUT_GET, 'id', FILTER_VALIDATE_INT);
if (!$bookingID) {
    die("<div class='alert error'>Invalid booking ID</div>");
}

try {
    $DBC = new mysqli(DBHOST, DBUSER, DBPASSWORD, DBDATABASE, DBPORT);
    if ($DBC->connect_errno) {
        throw new Exception("Database connection failed: " . $DBC->connect_error);
    }

    if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['submit'])) {
        $roomID = filter_input(INPUT_POST, 'room', FILTER_VALIDATE_INT);
        $checkin = filter_input(INPUT_POST, 'checkin', FILTER_SANITIZE_STRING);
        $checkout = filter_input(INPUT_POST, 'checkout', FILTER_SANITIZE_STRING);
        $contactnumber = filter_input(INPUT_POST, 'contactnumber', FILTER_SANITIZE_STRING);
        $booking_extras = filter_input(INPUT_POST, 'booking_extras', FILTER_SANITIZE_STRING);
        $room_review = filter_input(INPUT_POST, 'room_review', FILTER_SANITIZE_STRING);

        $errors = [];

        $checkinTimestamp = strtotime($checkin);
        $checkoutTimestamp = strtotime($checkout);

        if (!$checkinTimestamp) {
            $errors[] = "Invalid check-in date";
        }

        if (!$checkoutTimestamp) {
            $errors[] = "Invalid check-out date";
        }

        if ($checkinTimestamp && $checkoutTimestamp && $checkinTimestamp >= $checkoutTimestamp) {
            $errors[] = "Check-out date must be after check-in date";
        }

        if (empty($errors)) {
            $stmt = $DBC->prepare("
                UPDATE booking SET 
                    roomID = ?, 
                    check_in_date = ?, 
                    check_out_date = ?,
                    contactnumber = ?,
                    booking_extras = ?,
                    room_review = ?
                WHERE bookingID = ?
            ");

            $stmt->bind_param('isssssi', 
                $roomID,
                $checkin,
                $checkout,
                $contactnumber,
                $booking_extras,
                $room_review,
                $bookingID
            );

            if ($stmt->execute()) {
                $success = "Booking updated successfully";
            } else {
                $errors[] = "Update failed: " . $stmt->error;
            }
            $stmt->close();
        }
    }


    $stmt = $DBC->prepare("
        SELECT b.*, r.roomname 
        FROM booking b
        JOIN room r ON b.roomID = r.roomID
        WHERE b.bookingID = ?
    ");
    $stmt->bind_param('i', $bookingID);
    $stmt->execute();
    $booking = $stmt->get_result()->fetch_assoc();
    $stmt->close();


    $rooms = $DBC->query("SELECT roomID, roomname FROM room ORDER BY roomname");

} catch (Exception $e) {
    die("<div class='alert error'>Error: " . $e->getMessage() . "</div>");
} finally {
    if (isset($DBC) && $DBC instanceof mysqli) {
        $DBC->close();
    }
}
?>
