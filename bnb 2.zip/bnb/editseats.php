<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Edit Room_Review</title>
</head>
<body>
    <?php
        include "checksession.php";
        checkUser();
        loginStatus();
        
    //take the details about server and database
    include "config.php"; //load in any variables
    $DBC = mysqli_connect(DBHOST, DBUSER, DBPASSWORD, DBDATABASE, DBPORT);

    // Insert DB code from here onwards

// Check if the connection was good
if (mysqli_connect_error()) {
    echo "Error: Unable to connect to MySQL. " . mysqli_connect_error();
    exit(); // Stop processing the page further
}

// Function to clean input but not validate type and content
function cleanInput($data) {
    return htmlspecialchars(stripslashes(trim($data)));
}

// Check if id exists
if ($_SERVER['REQUEST_METHOD'] == "GET") {
    $id = $_GET['id'];
    if (empty($id) or !is_numeric($id)) {
        echo "<h2>Invalid booking id</h2>";
        exit();
    }
}

// On submit check if empty or not string and is submitted by POST
if (isset($_POST['submit']) and !empty($_POST['submit']) and ($_POST['submit'] == 'Update')) {
    $seat = cleanInput($_POST['room_review']);
    $id = cleanInput($_POST['id']);

    $query = "UPDATE `booking` SET room_review=? WHERE bookingID=?";
    
    $stmt = mysqli_prepare($DBC, $query); // Prepare the query
    mysqli_stmt_bind_param($stmt, 'si', $room_review, $id);
    
    mysqli_stmt_execute($stmt);
    
    echo "<h5>Room_review updated</h5>";
}

$query = "SELECT room_review FROM `booking` WHERE bookingID=" . $id;
$result = mysqli_query($DBC, $query);
$rowcount = mysqli_num_rows($result);
?>

<h1>Edit Room_Review</h1>
<h2>
    <a href="bookinglisting.php">[Return to the booking listing]</a>
    <a href="index.php">[Return to main page]</a>
</h2>

<div>
    <form method="POST">
        <div>
            <input type="hidden" name="id" value="<?php echo $id; ?>">
        </div>
        <?php
        if ($rowcount > 0) {
            $row = mysqli_fetch_assoc($result);
        ?>
        <div>
            <label for="seat">Room_Review:</label>
            <input type="text" id="room_reviews" name="seat" value="<?php echo $row['room_review']; ?>">
        </div>
        <?php
        } else {
            echo "<h5>No booking found</h5>";
        }
        ?>
        <br><br>
        <div>
            <input type="submit" name="submit" value="Update">
        </div>
    </form>
</div>

<?php
mysqli_free_result($result);
mysqli_close($DBC);
?>
</body>
</html>