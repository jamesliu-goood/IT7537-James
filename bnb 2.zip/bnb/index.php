<!DOCTYPE html>
<html>
<title>W3.CSS Template</title>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<?php

#include "checksession.php";
#checkUser();
?>
<h1>BIT608 Web Programming </h1>
<h2>Assessment case study web applicaiton temporary launch page</h2>
<ul>
<li><a href="/bnb/listcustomers.php">Customer listing</a>
<li><a href="/bnb/listrooms.php">Rooms listing</a>
<li><a href="/bnb/bookinglisting.php">Bookings listing</a>
<li><a href="/bnb/login.php">Login</a>
</ul>

</body>
</html>
